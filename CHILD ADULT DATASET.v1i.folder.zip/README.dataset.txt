# CHILD ADULT DATASET > 2024-03-08 1:39pm
https://universe.roboflow.com/vallabha-group-of-companies/child-adult-dataset

Provided by a Roboflow user
License: MIT

